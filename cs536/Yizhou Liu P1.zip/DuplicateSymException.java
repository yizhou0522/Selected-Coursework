//Yizhou Liu, liu773@wisc.edu
/** This class represents DuplicateSymTableException */
public class DuplicateSymException extends Exception{
    
}
