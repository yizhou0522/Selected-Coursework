//Yizhou Liu, liu773@wisc.edu
/** This class represent EmptySymTableException */
public class EmptySymTableException extends Exception {

}
